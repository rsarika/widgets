import {
  MetricEventAgent,
  MetricEventProduct,
  MetricEventVerb,
} from '@webex/internal-plugin-metrics/src/metrics.types';

import {METRIC_EVENT_NAMES} from './constants';
import {PRODUCT_NAME} from '../constants';

/**
 * Represents the taxonomy for a behavioral event in the metrics system.
 * @ignore
 * @typedef BehavioralEventTaxonomy
 * @property {MetricEventProduct} product - The product associated with the behavioral event.
 * @property {MetricEventAgent} agent - The agent responsible for the behavioral event.
 * @property {string} target - The target entity of the behavioral event.
 * @property {MetricEventVerb} verb - The action or verb describing the behavioral event.
 *
 * @category Metrics
 * @type BehavioralEvents
 */
export type BehavioralEventTaxonomy = {
  product: MetricEventProduct;
  agent: MetricEventAgent;
  target: string;
  verb: MetricEventVerb;
};

const product: MetricEventProduct = PRODUCT_NAME;

// Adding new metrics? Please add them to the Cypher CC metrics wiki
/**
 * @ignore
 * @typedoc
 * A mapping between metric event names and their corresponding behavioral event taxonomy definitions.
 *
 * This map is used to associate each event (such as login, logout, task actions, etc.)
 * with a structured taxonomy object that describes the product, agent, target, and verb
 * for behavioral analytics and metrics reporting.
 *
 * The keys are string constants from `METRIC_EVENT_NAMES`, and the values are
 * `BehavioralEventTaxonomy` objects that define the event's context.
 *
 * @example
 * ```typescript
 * const taxonomy = eventTaxonomyMap[METRIC_EVENT_NAMES.STATION_LOGIN_SUCCESS];
 * // taxonomy = { product, agent: 'user', target: 'station_login', verb: 'complete' }
 * ```
 *
 * @see BehavioralEventTaxonomy
 * @see METRIC_EVENT_NAMES
 */
const eventTaxonomyMap: Record<string, BehavioralEventTaxonomy> = {
  [METRIC_EVENT_NAMES.STATION_LOGIN_SUCCESS]: {
    product,
    agent: 'user',
    target: 'station_login',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.STATION_LOGIN_FAILED]: {
    product,
    agent: 'user',
    target: 'station_login',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.STATION_LOGOUT_SUCCESS]: {
    product,
    agent: 'user',
    target: 'station_logout',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.STATION_LOGOUT_FAILED]: {
    product,
    agent: 'user',
    target: 'station_logout',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.STATION_RELOGIN_SUCCESS]: {
    product,
    agent: 'user',
    target: 'station_relogin',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.STATION_RELOGIN_FAILED]: {
    product,
    agent: 'user',
    target: 'station_relogin',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.AGENT_STATE_CHANGE_SUCCESS]: {
    product,
    agent: 'user',
    target: 'state_change',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.AGENT_STATE_CHANGE_FAILED]: {
    product,
    agent: 'user',
    target: 'state_change',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.FETCH_BUDDY_AGENTS_SUCCESS]: {
    product,
    agent: 'user',
    target: 'buddy_agents_fetch',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.FETCH_BUDDY_AGENTS_FAILED]: {
    product,
    agent: 'user',
    target: 'buddy_agents_fetch',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.WEBSOCKET_REGISTER_SUCCESS]: {
    product,
    agent: 'user',
    target: 'websocket_register',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.WEBSOCKET_REGISTER_FAILED]: {
    product,
    agent: 'user',
    target: 'websocket_register',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.AGENT_RONA]: {
    product,
    agent: 'service',
    target: 'agent_rona',
    verb: 'set',
  },
  [METRIC_EVENT_NAMES.AGENT_CONTACT_ASSIGN_FAILED]: {
    product,
    agent: 'service',
    target: 'agent_contact_assign',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.AGENT_INVITE_FAILED]: {
    product,
    agent: 'service',
    target: 'agent_invite',
    verb: 'fail',
  },

  // Added Task events
  [METRIC_EVENT_NAMES.TASK_ACCEPT_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_accept',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_ACCEPT_FAILED]: {
    product,
    agent: 'user',
    target: 'task_accept',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_DECLINE_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_decline',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_DECLINE_FAILED]: {
    product,
    agent: 'user',
    target: 'task_decline',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_END_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_end',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_END_FAILED]: {
    product,
    agent: 'user',
    target: 'task_end',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_WRAPUP_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_wrapup',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_WRAPUP_FAILED]: {
    product,
    agent: 'user',
    target: 'task_wrapup',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_HOLD_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_hold',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_HOLD_FAILED]: {
    product,
    agent: 'user',
    target: 'task_hold',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_RESUME_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_resume',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_RESUME_FAILED]: {
    product,
    agent: 'user',
    target: 'task_resume',
    verb: 'fail',
  },

  // Advanced Tasks handling
  [METRIC_EVENT_NAMES.TASK_CONSULT_START_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_consult_start',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_CONSULT_START_FAILED]: {
    product,
    agent: 'user',
    target: 'task_consult_start',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_CONSULT_END_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_consult_end',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_CONSULT_END_FAILED]: {
    product,
    agent: 'user',
    target: 'task_consult_end',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_TRANSFER_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_transfer',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_TRANSFER_FAILED]: {
    product,
    agent: 'user',
    target: 'task_transfer',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_RESUME_RECORDING_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_resume_recording',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_RESUME_RECORDING_FAILED]: {
    product,
    agent: 'user',
    target: 'task_resume_recording',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_PAUSE_RECORDING_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_pause_recording',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_PAUSE_RECORDING_FAILED]: {
    product,
    agent: 'user',
    target: 'task_pause_recording',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_ACCEPT_CONSULT_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_accept_consult',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_ACCEPT_CONSULT_FAILED]: {
    product,
    agent: 'user',
    target: 'task_accept_consult',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_AUTO_ANSWER_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_auto_answer',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_AUTO_ANSWER_FAILED]: {
    product,
    agent: 'user',
    target: 'task_auto_answer',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_OUTDIAL_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_outdial',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_OUTDIAL_FAILED]: {
    product,
    agent: 'user',
    target: 'task_outdial',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.WXAPP_TASK_MUTE_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_mute_webex_together',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.WXAPP_TASK_MUTE_FAILED]: {
    product,
    agent: 'user',
    target: 'task_mute_webex_together',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.WXAPP_TASK_DTMF_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_dtmf_webex_together',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.WXAPP_TASK_DTMF_FAILED]: {
    product,
    agent: 'user',
    target: 'task_dtmf_webex_together',
    verb: 'fail',
  },

  // Webex Together (wxApp)
  [METRIC_EVENT_NAMES.WXAPP_TASK_ACCEPT_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_accept_webex_together',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.WXAPP_TASK_ACCEPT_FAILED]: {
    product,
    agent: 'user',
    target: 'task_accept_webex_together',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.WXAPP_TASK_DECLINE_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_reject_webex_together',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.WXAPP_TASK_DECLINE_FAILED]: {
    product,
    agent: 'user',
    target: 'task_reject_webex_together',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.WXAPP_SESSION_INIT_SUCCESS]: {
    product,
    agent: 'user',
    target: 'webex_together_session_init',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.WXAPP_SESSION_INIT_FAILED]: {
    product,
    agent: 'user',
    target: 'webex_together_session_init',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.WXAPP_SESSION_SKIPPED]: {
    product,
    agent: 'user',
    target: 'webex_together_session_init',
    verb: 'ignore',
  },
  [METRIC_EVENT_NAMES.WXAPP_USERSUB_PUBLISH_SUCCESS]: {
    product,
    agent: 'user',
    target: 'webex_together_usersub_publish',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.WXAPP_USERSUB_PUBLISH_FAILED]: {
    product,
    agent: 'user',
    target: 'webex_together_usersub_publish',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.WXAPP_MERCURY_SUBSCRIBE_SUCCESS]: {
    product,
    agent: 'user',
    target: 'webex_together_mercury_subscribe',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.WXAPP_MERCURY_SUBSCRIBE_FAILED]: {
    product,
    agent: 'user',
    target: 'webex_together_mercury_subscribe',
    verb: 'fail',
  },

  // Conference Tasks
  [METRIC_EVENT_NAMES.TASK_CONFERENCE_START_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_conference_start',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_CONFERENCE_START_FAILED]: {
    product,
    agent: 'user',
    target: 'task_conference_start',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_CONFERENCE_END_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_conference_end',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_CONFERENCE_END_FAILED]: {
    product,
    agent: 'user',
    target: 'task_conference_end',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.TASK_CONFERENCE_TRANSFER_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_conference_transfer',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_CONFERENCE_TRANSFER_FAILED]: {
    product,
    agent: 'user',
    target: 'task_conference_transfer',
    verb: 'fail',
  },

  // Conference Exit
  [METRIC_EVENT_NAMES.TASK_CONFERENCE_EXIT_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_conference_exit',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_CONFERENCE_EXIT_FAILED]: {
    product,
    agent: 'user',
    target: 'task_conference_exit',
    verb: 'fail',
  },

  // Conference Participant Drop
  [METRIC_EVENT_NAMES.TASK_CONFERENCE_PARTICIPANT_DROP_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_conference_participant_drop',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_CONFERENCE_PARTICIPANT_DROP_FAILED]: {
    product,
    agent: 'user',
    target: 'task_conference_participant_drop',
    verb: 'fail',
  },

  // Switch Call
  [METRIC_EVENT_NAMES.TASK_SWITCH_CALL_SUCCESS]: {
    product,
    agent: 'user',
    target: 'task_switch_call',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.TASK_SWITCH_CALL_FAILED]: {
    product,
    agent: 'user',
    target: 'task_switch_call',
    verb: 'fail',
  },

  // upload logs
  [METRIC_EVENT_NAMES.UPLOAD_LOGS_SUCCESS]: {
    product,
    agent: 'user',
    target: 'upload_logs',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.UPLOAD_LOGS_FAILED]: {
    product,
    agent: 'user',
    target: 'upload_logs',
    verb: 'fail',
  },

  // update profile
  [METRIC_EVENT_NAMES.AGENT_DEVICE_TYPE_UPDATE_SUCCESS]: {
    product,
    agent: 'user',
    target: 'agent_device_type_update',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.AGENT_DEVICE_TYPE_UPDATE_FAILED]: {
    product,
    agent: 'user',
    target: 'agent_device_type_update',
    verb: 'fail',
  },

  // EntryPoint API Events
  [METRIC_EVENT_NAMES.ENTRYPOINT_FETCH_SUCCESS]: {
    product,
    agent: 'user',
    target: 'entrypoint_fetch',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.ENTRYPOINT_FETCH_FAILED]: {
    product,
    agent: 'user',
    target: 'entrypoint_fetch',
    verb: 'fail',
  },

  // AddressBook API Events
  [METRIC_EVENT_NAMES.ADDRESSBOOK_FETCH_SUCCESS]: {
    product,
    agent: 'user',
    target: 'addressbook_fetch',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.ADDRESSBOOK_FETCH_FAILED]: {
    product,
    agent: 'user',
    target: 'addressbook_fetch',
    verb: 'fail',
  },

  // Queue API Events
  [METRIC_EVENT_NAMES.QUEUE_FETCH_SUCCESS]: {
    product,
    agent: 'user',
    target: 'queue_fetch',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.QUEUE_FETCH_FAILED]: {
    product,
    agent: 'user',
    target: 'queue_fetch',
    verb: 'fail',
  },

  // Outdial ANI API Events
  [METRIC_EVENT_NAMES.OUTDIAL_ANI_EP_FETCH_SUCCESS]: {
    product,
    agent: 'user',
    target: 'outdial_ani_ep_fetch',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.OUTDIAL_ANI_EP_FETCH_FAILED]: {
    product,
    agent: 'user',
    target: 'outdial_ani_ep_fetch',
    verb: 'fail',
  },

  // Campaign Preview API Events
  [METRIC_EVENT_NAMES.CAMPAIGN_PREVIEW_ACCEPT_SUCCESS]: {
    product,
    agent: 'user',
    target: 'campaign_preview_accept',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.CAMPAIGN_PREVIEW_ACCEPT_FAILED]: {
    product,
    agent: 'user',
    target: 'campaign_preview_accept',
    verb: 'fail',
  },

  // Campaign Preview Skip API Events
  [METRIC_EVENT_NAMES.CAMPAIGN_PREVIEW_SKIP_SUCCESS]: {
    product,
    agent: 'user',
    target: 'campaign_preview_skip',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.CAMPAIGN_PREVIEW_SKIP_FAILED]: {
    product,
    agent: 'user',
    target: 'campaign_preview_skip',
    verb: 'fail',
  },

  // Campaign Preview Remove API Events
  [METRIC_EVENT_NAMES.CAMPAIGN_PREVIEW_REMOVE_SUCCESS]: {
    product,
    agent: 'user',
    target: 'campaign_preview_remove',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.CAMPAIGN_PREVIEW_REMOVE_FAILED]: {
    product,
    agent: 'user',
    target: 'campaign_preview_remove',
    verb: 'fail',
  },

  // User Preference API Events
  [METRIC_EVENT_NAMES.USER_PREFERENCE_GET_SUCCESS]: {
    product,
    agent: 'user',
    target: 'user_preference_get',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.USER_PREFERENCE_GET_FAILED]: {
    product,
    agent: 'user',
    target: 'user_preference_get',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.USER_PREFERENCE_CREATE_SUCCESS]: {
    product,
    agent: 'user',
    target: 'user_preference_create',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.USER_PREFERENCE_CREATE_FAILED]: {
    product,
    agent: 'user',
    target: 'user_preference_create',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.USER_PREFERENCE_UPDATE_SUCCESS]: {
    product,
    agent: 'user',
    target: 'user_preference_update',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.USER_PREFERENCE_UPDATE_FAILED]: {
    product,
    agent: 'user',
    target: 'user_preference_update',
    verb: 'fail',
  },
  [METRIC_EVENT_NAMES.USER_PREFERENCE_DELETE_SUCCESS]: {
    product,
    agent: 'user',
    target: 'user_preference_delete',
    verb: 'complete',
  },
  [METRIC_EVENT_NAMES.USER_PREFERENCE_DELETE_FAILED]: {
    product,
    agent: 'user',
    target: 'user_preference_delete',
    verb: 'fail',
  },
};

/**
 * Get the taxonomy information for a given behavioral event name.
 * @ignore
 * @param name - The name of the metric event to look up.
 * @returns The corresponding {@link BehavioralEventTaxonomy} if found, otherwise `undefined`.
 *
 * @typedoc
 */
export function getEventTaxonomy(name: METRIC_EVENT_NAMES): BehavioralEventTaxonomy | undefined {
  return eventTaxonomyMap[name];
}
